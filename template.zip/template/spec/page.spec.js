describe('Javascript arithmetic', function(){

  it('should add correctly', function(){
    expect(2+2).toBe(4);
  });

});
